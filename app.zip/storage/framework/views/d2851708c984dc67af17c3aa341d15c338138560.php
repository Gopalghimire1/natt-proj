<?php $__env->startSection('title','User'); ?>
<?php $__env->startSection('content'); ?>
<div class="header"  style="background:#890E4F; color:#ffffff; height:55px; margin:0px;">
    <center><p style="padding:20px; font-size:18px; font-family:"> User List</h3></p>
</div>
 <section class="container">
 <div class="row" style=" padding:2rem;" >
    <div class="cell-md-11" >
            <?php echo $__env->make('back.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form method="post" action="<?php echo e(route('admin.user.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label>Name</label>
                        <input type="text"  name="username" placeholder="Enter name of user" required/>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email"  name="email" placeholder="Enter email of user" required/>
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <input type="password"  name="password" required />
                    </div>

                    <div class="form-group">
                        <button class="button success">Submit data</button>
                    </div>
            </form>

        </div>


        <div style="margin-top: 1rem;">
            <table class="table table-border cell-border">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                       <?php echo e($u->username); ?>

                    </td>
                    <td><?php echo e($u->email); ?></td>
                    <td>
                        <?php if($u->id != 1): ?>
                            <a href="<?php echo e(route('admin.user.delete',$u->id)); ?>">Delete</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>

    </div>

 </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script>
      function readURL(input) {
         if (input.files && input.files[0]) {
             var reader = new FileReader();

             reader.onload = function (e) {
                 $('#photo')
                     .attr('src', e.target.result);
             };

             reader.readAsDataURL(input.files[0]);
         }
     }

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/back/user/list.blade.php ENDPATH**/ ?>