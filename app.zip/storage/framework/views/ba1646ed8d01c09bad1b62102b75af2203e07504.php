<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset('front/img/1.jpg')); ?>);">
    <div class="breadcrumb-overlay">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2><?php echo e($pageIitem->title); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Page</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="container mt-5 mb-5">
    <div class="card" >
        <div class="card-body">
            <div class="row">
                <div class="col-md-12 col-12">
                    <h4 class="mb-50"><?php echo e($pageIitem->title); ?></h4>
                    <hr>
                    <?php if($pageIitem->image != null): ?>
                        <div class="img">
                            <img src="<?php echo e(asset($pageIitem->image)); ?>" class="w-100" alt="" style="height: 300px;">
                        </div>
                    <?php endif; ?>

                    <div class="detail">
                        <p><?php echo $pageIitem->subdetail; ?></p>
                    </div>

                    <div class="detail">
                        <p><?php echo $pageIitem->detail; ?></p>
                    </div>

                </div>
            </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/page/dynamic.blade.php ENDPATH**/ ?>