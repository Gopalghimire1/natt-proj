<?php $__env->startSection('title','Downloads'); ?>
<?php $__env->startSection('content'); ?>
<div class="header"  style="background:#890E4F; color:#ffffff; height:55px; margin:0px;">
    <center><p style="padding:20px; font-size:18px; font-family:">Download</h3></p>
</div>
 <section class="container">
 <div class="row" style=" padding:2rem;" >
        <div class="cell-md-11" >
            <form method="post" action="<?php echo e(route('admin.download.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" name="title" placeholder="Enter name of the title" />
                    </div>
                    <div class="form-group container" style="border: 1px black solid; padding-bottom:5px;" >
                        <p>Photo</p>
                        <img src="" style="height: 200px;" id="photo"/>
                        <input type="file" name="file" data-role="file" onchange="readURL(this);" data-button-title="..." >
                    </div>

                    <div class="form-group">
                        <button class="button success">Submit data</button>
                    </div>
            </form>

        </div>



    </div>

    <div style="margin-top: 1rem;">
        <table class="table table-border cell-border">
            <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Action</th>
            </tr>
            <?php $__currentLoopData = $download; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                   <a target="_blank" href="<?php echo e(asset($adv->file)); ?>">Click to download</a>
                </td>
                <td><?php echo e($adv->title); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.download.delete',$adv->id)); ?>">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
 </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


<script>
      function readURL(input) {
         if (input.files && input.files[0]) {
             var reader = new FileReader();

             reader.onload = function (e) {
                 $('#photo')
                     .attr('src', e.target.result);
             };

             reader.readAsDataURL(input.files[0]);
         }
     }

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/back/download/list.blade.php ENDPATH**/ ?>