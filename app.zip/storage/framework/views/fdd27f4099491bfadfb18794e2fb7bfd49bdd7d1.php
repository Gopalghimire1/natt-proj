<div class="p-3">
    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="single-news">
        <div class="news-title">
            <a href="<?php echo e(route('event.single',$new->id)); ?>"><?php echo e($new->title); ?></a>
        </div>
        <div class="news-date">
            &#128197; <?php echo e($new->eventdate); ?>, <span class="ml-3"><?php echo e($new->eventtime); ?></span>
        </div>
        <div>
            <div class="row">
                <div class="col-4 text-center">
                    <img src="<?php echo e(asset($new->image)); ?>" class="news-image w-100" alt="">
                </div>
                <div class="col-8 d-flex align-items-center">
                    <div class="news-text">
                         <?php echo $new->descr; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



 </div>
<?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/event.blade.php ENDPATH**/ ?>