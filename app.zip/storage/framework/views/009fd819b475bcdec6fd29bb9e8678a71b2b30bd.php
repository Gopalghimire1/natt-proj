<div class="p-3">
    <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="single-news">
        <div class="news-title">
            <a href=""><?php echo e($new->name); ?></a>
        </div>
        
        <div>
            <div class="row">
                <div class="col-4 text-center">
                    <img src="<?php echo e(asset($new->image)); ?>" class="news-image w-100" alt="">
                </div>
                <div class="col-8 d-flex align-items-center">
                    <div class="news-text">
                         <?php echo $new->detail; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



 </div>
<?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/activity.blade.php ENDPATH**/ ?>