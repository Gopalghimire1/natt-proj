<?php
    if(isset($data[$key])){
        $section[$key]=json_decode($data[$key]);                                   
    }else{
        $section[$key]=[];
    }
?>
<div class="">
<span class="btn btn-primary btn-sm" onclick="add_custom_link_<?php echo e($key); ?>()">Add</button>

</div>
    <div id="custom_links_<?php echo e($key); ?>">
        <?php $__currentLoopData = $section[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <div id="custom_link_<?php echo e($key); ?>_<?php echo e($l->id); ?>">
            <input class="custom_link_<?php echo e($key); ?>" type="hidden" name="input_<?php echo e($key); ?>[]" id="input_<?php echo e($key); ?>_<?php echo e($l->id); ?>" value="<?php echo e($l->id); ?>">
            <div class="d-flex" >
                <input type="text" style="flex:4;" placeholder="text" name="link_text_<?php echo e($key); ?>_<?php echo e($l->id); ?>" required value="<?php echo e($l->text); ?>">
                <input type="text" style="flex:4;" placeholder="link" name="link_link_<?php echo e($key); ?>_<?php echo e($l->id); ?>" required value="<?php echo e($l->link); ?>">
                <span  style="flex:2" class="btn btn-link" onclick="del_custom_link_<?php echo e($key); ?>(<?php echo e($l->id); ?>)">
                    delete
                </span>
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<div >

</div>

<script>
    custom_link_<?php echo e($key); ?>_id=0;
    document.querySelectorAll('.custom_link_<?php echo e($key); ?>').forEach(element => {
        if(parseInt( element.value)>custom_link_<?php echo e($key); ?>_id){
            custom_link_<?php echo e($key); ?>_id= parseInt(element.value);
        }
    });
   
    custom_link_<?php echo e($key); ?>_id+=1;
    
    
    function add_custom_link_<?php echo e($key); ?>(){
        id=custom_link_<?php echo e($key); ?>_id;
        html= '<div id="custom_link_<?php echo e($key); ?>_'+id+'"><input class="custom_link_<?php echo e($key); ?>" type="hidden" name="input_<?php echo e($key); ?>[]" id="input_<?php echo e($key); ?>_'+id+'" value="'+id+'" > <div class="d-flex" ><input type="text" style="flex:4;" placeholder="text" name="link_text_<?php echo e($key); ?>_'+id+'"> <input type="text" style="flex:4;" placeholder="link" name="link_link_<?php echo e($key); ?>_'+id+'"><span style="flex:2"  class="btn btn-link" onclick="del_custom_link_<?php echo e($key); ?>('+id+')">delete</span></div> </div>';
        $('#custom_links_<?php echo e($key); ?>').append(html);
        custom_link_<?php echo e($key); ?>_id+=1;
    }
    function del_custom_link_<?php echo e($key); ?>(id){
        $("#custom_link_<?php echo e($key); ?>_"+id).remove();
    }
</script><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/config/multiplelink.blade.php ENDPATH**/ ?>