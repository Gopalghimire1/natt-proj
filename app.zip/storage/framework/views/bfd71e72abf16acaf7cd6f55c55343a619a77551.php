<?php $__env->startSection('title','New listing'); ?>
<?php $__env->startSection('content'); ?>
<div class="header"  style="background:#890E4F; color:#ffffff; height:55px; margin:0px;">
    <center><p style="padding:20px; font-size:18px; font-family:"> Menu Listing</h3></p>
</div>
<section class="container">
    <div class="row" style=" padding:2rem;" >
           <div class="cell-md-8" >
               <form action="<?php echo e(route('admin.menu.store')); ?>" method="POST">
                   <?php echo csrf_field(); ?>
                   <div class="form-group">
                        <label for="title"> Menu Title <span style="color:red;">*</span></label>
                        <input type="text" name="title" placeholder="Enter Menu Title" class="form-control" required>
                        
                   </div>

                   <div class="form-group">
                       <label for="title"> Parent Menu </label>
                       <select name="parent_id" class="form-control">
                           <option value="0">==== Select Parent Menu ====</option>
                            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->getName()); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                    </div>

                    <div class="form-group">
                        <label for="title"> Page Display </label>
                        <select name="type" class="form-control">
                            <option >==== Select Page Type ====</option>
                            <option value="1">For Simple</option>
                            <option value="2">For Pdf file upload</option>
                            <option value="3">For Leadership Member</option>
                        </select>
                     </div>

                  <div class="form-group">
                       <button class="button success">Submit data</button>
                       <input type="button" class="button" value="Cancel" onclick="window.location.href='<?php echo e(route('admin.menu.index')); ?>'">
                  </div>
               </form>
           </div>
       </div>

       <div>

        <div class="row" style=" padding:2rem;" >
            <div class="cell-md-8" >
                <table class="table table-border cell-border">
                    <tr>
                        <th>Menu</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = App\Models\Menu::with('submenu')->where('parent_id',0)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($attr->title); ?>

                                <?php if(count($attr->submenu)): ?>
                                    <?php $__currentLoopData = $attr->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li><?php echo e($item->title); ?>

                                                    <a href="<?php echo e(route('admin.menu.delete',$item->id)); ?>" class="button danger" onclick="return confirm('Are You Sure?');">Del</a>
                                                    <a href="<?php echo e(route('admin.menu.manage',$item->id)); ?>" class="button success" >Manage</a>
                                            </li>
                                            <?php if(count($item->submenu)): ?>
                                                <?php $__currentLoopData = $item->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <ul>
                                                        <li><?php echo e($item1->title); ?>

                                                          <a href="<?php echo e(route('admin.menu.delete',$item1->id)); ?>" class="button danger" onclick="return confirm('Are You Sure?');">Del</a>
                                                          <a href="<?php echo e(route('admin.menu.manage',$item1->id)); ?>" class="button success" >Manage</a>
                                                        </li>
                                                    </ul>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.menu.delete',$attr->id)); ?>" class="button danger" onclick="return confirm('Are You Sure?');">Del</a>

                               

                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
       </div>
   </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/back/menu/list.blade.php ENDPATH**/ ?>