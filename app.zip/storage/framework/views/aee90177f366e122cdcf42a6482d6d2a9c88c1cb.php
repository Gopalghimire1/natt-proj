<?php if(Session::has('success')): ?>
    <div style="padding: 10px; background: rgb(36, 224, 115); color:white; margin: 20px 0;">
       <p><?php echo e(Session::get('success')); ?></p>
    </div>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
<div style="padding: 10px; background: rgb(228, 99, 25); color:white; margin: 20px 0;">
    <p><?php echo e(Session::get('warning')); ?></p>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/back/alert.blade.php ENDPATH**/ ?>