<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset('front/img/1.jpg')); ?>);" >
    <div class="breadcrumb-overlay">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2><?php echo e($gallery->name); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('gallery')); ?>"> Gallery</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Detail</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container mt-5 mb-5">


    <div class="gallery">
        <div class="row">
            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col-md-4 col-sm-12 mb-4">
                    <a href="<?php echo e(asset($i->image->image)); ?>" class="big" rel="rel<?php echo e($i->image->id); ?>">
                        <img class="img-thumbnail w-100" style="height: 250px;" src="<?php echo e(asset($i->image->image)); ?>" alt="" >
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
 <link rel="stylesheet" href="<?php echo e(asset('front/gallery/dist/simple-lightbox.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('front/gallery/dist/simple-lightbox.min.js')); ?>"></script>

<script src="<?php echo e(asset('front/gallery/dist/simple-lightbox.jquery.min.js')); ?>"></script>

<script>

    var gallery = $('.gallery a').simpleLightbox({


    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/page/gallery_detail.blade.php ENDPATH**/ ?>