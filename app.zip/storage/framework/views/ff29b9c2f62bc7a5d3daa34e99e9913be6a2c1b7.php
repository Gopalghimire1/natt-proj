<div class="footer" >
    <div class="container-custom">
        <div class="row">
            <div class="col-lg-3">
                <div class="footer-section">
                    <?php
                        $links = [];
                        $links1 = [];
                        $links2 = [];
                        $data = custom_config('footer_1_links');
                        $data1 = custom_config('footer_2_links');
                        $data2 = custom_config('footer_2_links');
                        if($data!=null && $data->value!= null){
                            $links = json_decode(custom_config('footer_1_links')->value);
                        }
                        if($data1!=null && $data1->value!= null){
                            $links1 = json_decode(custom_config('footer_2_links')->value);
                        }
                        if($data2!=null && $data2->value!= null){
                            $links2 = json_decode(custom_config('footer_3_links')->value);
                        }
                    ?>
                    <div class="title">
                       <?php echo e(custom_config('footer_title_1')->value); ?>

                    </div>
                    <ul>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($link->link); ?>" style="font-size: 13px;"><?php echo e($link->text); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="footer-section">
                    <div class="title">
                        <?php echo e(custom_config('footer_title_2')->value); ?>

                    </div>
                    <ul>
                        <?php $__currentLoopData = $links1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($link->link); ?>" style="font-size: 13px;"><?php echo e($link->text); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="footer-section">
                    <div class="title">
                        <?php echo e(custom_config('footer_title_3')->value); ?>

                    </div>
                    <ul>
                        <?php $__currentLoopData = $links2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e($link->link); ?>" style="font-size: 13px;"><?php echo e($link->text); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <?php echo custom_config('theme_facebook')->value; ?>

            </div>
        </div>
        <hr>
        <div class="text-center m-2">
            <div class="row last-footer">
                <div class="container" style="font-size: 12px;">
                    <?php echo custom_config('copyright')->value; ?>

                </div>
             </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/layouts/footer.blade.php ENDPATH**/ ?>