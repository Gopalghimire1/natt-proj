<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset('front/img/1.jpg')); ?>);">
    <div class="breadcrumb-overlay">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2><?php echo e($menu->title); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Page</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="container mt-5 mb-5">
    <div class="card" >
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $leader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-12">
                    <div class="row">
                        <div class="col-md-4 col-6">
                            <img src="<?php echo e(asset($li->image)); ?>" class="img-thumbnail w-100" alt="">
                        </div>

                        <div class="col-md-8 col-6">
                            <h5 style="color: #00a2de; font-weight: 600;"><?php echo e($li->name); ?></h5>
                           <span style="color: #ec9831;">(<?php echo e($li->designation); ?>)</span>
                           <p><?php echo e($li->addresss); ?></p>
                           <span><?php echo e($li->phone); ?></span>
                           <h6><a href="<?php echo e($li->website); ?>" target="_blank" style="text-decoration: none;color:#ec9831;"><?php echo e($li->website); ?></a></h6>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/page/leadership.blade.php ENDPATH**/ ?>