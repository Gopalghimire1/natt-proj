<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset('front/img/1.jpg')); ?>);">
    <div class="breadcrumb-overlay">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2><?php echo e($member->company); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item"><a href="/members">Members</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Details</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="container mt-5 mb-5">
    <div class="card" >
        <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 col-12 text-center mb-4">
                            <img src="<?php echo e(asset($member->image)); ?>" style="height: 250px;" class="img-thumbnail w-100" alt="">
                            <h6 style="color: #00a2de; font-weight: 500;" class="mt-2"><?php echo e($member->name); ?></h6>
                            <span style="color: #ec9831;">(<?php echo e($member->designation); ?>)</span>

                        </div>
                        <div class="col-md-9 col-12" >

                                    <strong>Natta Member ID :</strong>  <?php echo e($member->memberid); ?> <br><br>
                                    <strong>Company Name :</strong> <?php echo e($member->company); ?> <br><br>
                                    <strong>Telephone :</strong> <?php echo e($member->phone); ?> <br><br>
                                    <strong>Office Address :</strong> <?php echo e($member->addresss); ?> <br><br>
                                    <strong>Email Address :</strong> <?php echo e($member->gmail); ?> <br><br>
                                    <strong>Website :</strong> <a href="<?php echo e($member->website); ?>"><?php echo e($member->website); ?></a>
                        </div>
                    </div>
        </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/member/single.blade.php ENDPATH**/ ?>