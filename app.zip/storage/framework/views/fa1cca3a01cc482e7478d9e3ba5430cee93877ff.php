<?php $__env->startSection('content'); ?>

  

  <div class="container-custom">
      <div class="mt-2">
          <h2 class="widget-text">Welcome</h2>
          <img class="w-100" src="<?php echo e(asset(custom_config('banner_image')->value)); ?>" alt="">
      </div>
    <div class="row my-3">
      <div class="col-lg-5 h-350">
        <div class="tabs h-100" id="main-tab">
          <div class="tab-btn-bar" >
            <button class="tab-btn active" data-of="main-tab" data-for="news">News</button>
            <button class="tab-btn" data-of="main-tab" data-for="events">Events</button>
            <button class="tab-btn" data-of="main-tab" data-for="activity">Activities</button>
          </div>
          <div class="tab-container">
            <div class="tab-item active" id="news"><?php echo $__env->make('front.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="tab-item " id="events"><?php echo $__env->make('front.event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            <div class="tab-item " id="activity"><?php echo $__env->make('front.activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="updates h-350">
          <div class="updates-title">
            Updates
          </div>
          <marquee behavior="" onmouseover="this.stop();" onmouseout="this.start();" direction="up">
              <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <ul class="updates-list">
                <li> <a href="<?php echo e(route('news.single',$item->id)); ?>"><?php echo e($item->title); ?></a></li>
              </ul>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </marquee>
        </div>

        <div class="theme-video mt-3">
            <div class="video">
                <?php echo custom_config('theme_video')->value; ?>

            </div>
          
          
        </div>
      </div>
      <div class="col-md-3 text-center">
         <?php if($advs->count()>0): ?>
            <?php $__currentLoopData = $advs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->link != null): ?>
                <div class="mb-3">
                    <a href="<?php echo e($item->link); ?>}}"><img class="w-100" style="height: 150px;" src="<?php echo e(asset($item->image)); ?>" alt=""></a>
                </div>
            <?php else: ?>
                <div class="mb-3">
                    <img class="w-100" style="height: 150px;" src="<?php echo e(asset($item->image)); ?>" alt="">
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
                <div style="height: 150px; width: 300px; background: rgb(120, 140, 196); margin-bottom: 10px;">
                    <div style="padding: 4rem; color:white;">
                        <strong>Advertise</strong>
                    </div>
                </div>
                <div style="height: 150px; width: 300px; background: rgb(120, 140, 196)">
                    <div style="padding: 4rem; color:white;">
                        <strong>Advertise</strong>
                    </div>
                </div>
                <?php endif; ?>
        </div>
      <div class="mt-3">
        <?php if($adv->count()>0): ?>
            <marquee behavior="" onmouseover="this.stop();" onmouseout="this.start();" direction="left">
                <?php $__currentLoopData = $adv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->link != null): ?>
                    <span style="margin-right: 15px;">
                        <a href="<?php echo e($item->link); ?>}}"><img  style="height:150px; width: 300px;" src="<?php echo e(asset($item->image)); ?>" alt=""></a>
                    </span>
                    <?php else: ?>
                        <span style="margin-right: 15px;">
                            <img style="height:150px; width: 300px;" src="<?php echo e(asset($item->image)); ?>" alt="">
                        </span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </marquee>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="partners">
    <div class="container-custom">

      <div class="title">
      ASSOCIATES
      </div>
      <div class="list">
          <?php $__currentLoopData = $patner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item">
              <?php if($p->link != null): ?>
                <a href="<?php echo e($p->link); ?>">
                    <img src="<?php echo e(asset($p->image)); ?>" style="height: 100px;" class="w-100" alt="">
                </a>
              <?php else: ?>
                <img src="<?php echo e(asset($p->image)); ?>" style="height: 100px;" class="w-100" alt="">
              <?php endif; ?>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/index.blade.php ENDPATH**/ ?>