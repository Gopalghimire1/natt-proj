<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset('front/img/1.jpg')); ?>);" >

        <div class="breadcrumb-overlay">
            <div class="container h-100 ">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="breadcrumb-content">
                            <h2>Board Member List</h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="/">Board</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Members</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>

<div class="container mb-5">
        <?php
        $members=$board->boardmember;

        ?>
    <div class="row m-5 justify-content-center" >
        <?php for($i=0;$i<2;$i++): ?>
            <?php
                $secretary=$members[$i];
            ?>
            <div class="col-lg-3">
                <div class="member text-center">
                    <div class="square-img">
                        <img src="<?php echo e(asset($secretary->member->image)); ?>" alt="" class="w-100">
                    </div>
                    <div class="name ">
                        <?php echo e($secretary->member->name); ?>

                    </div>
                    <div class="desig">
                        ( <?php echo e($secretary->designation); ?>)
                    </div>
                </div>
            </div>
            <?php endfor; ?>
            <div class="row m-3" >
                <?php for($i=2;$i<$members->count();$i++): ?>
                    <?php
                        $secretary=$members[$i];
                    ?>
                        <div class="col-lg-3">
                            <div class="member text-center">
                                <div class="square-img">
                                    <img src="<?php echo e(asset($secretary->member->image)); ?>" alt="" class="w-100">
                                </div>
                                <div class="name ">
                                    <?php echo e($secretary->member->name); ?>

                                </div>
                                <div class="desig">
                                    ( <?php echo e($secretary->designation); ?>)
                                </div>
                            </div>
                        </div>
                <?php endfor; ?>
            </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/member/board.blade.php ENDPATH**/ ?>