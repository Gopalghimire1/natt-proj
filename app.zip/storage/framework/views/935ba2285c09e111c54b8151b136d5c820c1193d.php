<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area bg-img bg-overlay jarallax" style="background-image: url(<?php echo e(asset('front/img/1.jpg')); ?>);" >
    <div class="breadcrumb-overlay">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2>Member List</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Members</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    .al-map{
        justify-content: center;flex-wrap:wrap;display:flex;
        padding:10px 0px;
        background:var(--primary-color);
        /* margin:0px -15px; */
    }
    .al-link{
        height:30px;
        width: 30px;
        color:white;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>

<div class="container">
    <div class="card shadow">
        <div class="p-4">
            <div>
                <div class="row m-0">
                    <div class="col-md-12">
                        <input type="text" id="search" class="search form-control  " placeholder="Search Member" oninput="searchMember(this)">
                    </div>
                </div>
            </div>
            <hr>
            <div class="al-map  mt-3">
                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="al-link" href="#<?php echo e($item); ?>"><?php echo e($item); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <hr>
            <div class="row mt-5 mb-5 m-0">
                <?php $__currentLoopData = $sorted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4>
                        <?php echo e($key); ?>

                        <a name="<?php echo e(strtoupper($key)); ?>"></a>
                    </h4>
                    <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="searchable" data-value="<?php echo e($mem->company); ?>" style="border:1px #ccc solid; background:rgb(231, 224, 224); border-radius: 10px;">
                            <div style="margin: 10px;"><a href="<?php echo e(route('member.single',$mem->id)); ?>" style="text-decoration: none"><?php echo e($mem->company); ?> </a> [ Member ID: <?php echo e($mem->memberid); ?> ]</div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function searchMember(ele){
            keyword=ele.value.toLowerCase();
            if(keyword.length==0){
                $('.searchable').removeClass('d-none');
            }else{
                $('.searchable').each(function(){
                    name=this.dataset.value.toLowerCase();
                    console.log(name);
                    if(name.startsWith(keyword)){
                        $('.searchable').removeClass('d-none');

                    }else{
                        $('.searchable').addClass('d-none');
                    }
                });
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/front/member/list.blade.php ENDPATH**/ ?>