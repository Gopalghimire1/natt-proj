<?php $__env->startSection('title','Manage pages E-library'); ?>
<?php $__env->startSection('content'); ?>
<div class="header"  style="background:#890E4F; color:#ffffff; height:55px; margin:0px;">
    <center><p style="padding:20px; font-size:18px; font-family:"> Manage pages E-library </h3></p>
</div>
<section class="container">
    <div class="row" style=" padding:2rem;">
        <div class="cell-md-8" >
            <form method="post" action="<?php echo e(route('admin.elibrary.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Published Date</label>
                        <input type="text" id="nepali-calendar"  name="date" required>
                    </div>
                    <input type="hidden" name="menu_id" value="<?php echo e($menu->id); ?>">

                    <div class="form-group">
                        <label>Title</label>
                        <input type="text" name="title" placeholder="Enter name of the title" required/>
                    </div>

                    <div class="form-group container" style="border: 1px black solid; padding-bottom:5px;" >
                        <p>File</p>
                        <input type="file" name="file" data-role="file" onchange="readURL(this);" data-button-title="..." required>
                    </div>

                    <div class="form-group">
                        <label>Details</label>
                        <textarea data-role="textarea" name="detail"></textarea>
                    </div>

                    <div class="form-group">
                        <button class="button success">Submit data</button>
                        <input type="button" class="button" value="Cancel" onclick="window.location.href='<?php echo e(route('admin.menu.index')); ?>'">
                    </div>
            </form>

        </div>

    </div>

    <div class="row" style=" padding:2rem;" >
        <div class="cell-md-8" >
            <table class="table table-border cell-border" >
                <tr>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $elibrary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(asset($e->file)); ?>" target="_blank"><?php echo e($e->title); ?> </a></td>
                        <td><?php echo e($e->date); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.elibrary.delete',$e->id)); ?>" onclick="return confirm('Are you sure ?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

 <script>


     $(document).ready(function () {
        $('#nepali-calendar').nepaliDatePicker();
    });
     </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gopal Ghimire\Desktop\New folder\natta\natt-proj\resources\views/back/menu/manage1.blade.php ENDPATH**/ ?>